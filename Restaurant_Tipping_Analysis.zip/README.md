# Restaurant Tipping Behavior Analysis

An exploratory analysis of 244 restaurant bills using Python, pandas, matplotlib, and seaborn.

## What the project does
- Checks missing values, identical rows, and invalid numeric inputs.
- Calculates tip percentage per bill and distinguishes its mean from the overall bill-weighted rate.
- Compares days, meal times, and party sizes, including sample counts.
- Checks day/meal-time overlap and separates tips per bill from combined tip income.
- Calculates Pearson correlation and its corresponding simple-regression R-squared.

## Main findings
- Average tip percentage ranges from 15.3% to 17.0% across the four observed days. Friday has only 19 bills.
- Lunch and dinner average 16.4% and 16.0%; day and meal time overlap heavily.
- Party size and bill size have a correlation of about 0.60. Simple linear regression with an intercept using party size explains about 36% of sample bill-size variation.
- Average tip percentages generally fall with party size, but rise again for six-person tables. Five- and six-person parties have only 5 and 4 bills.
- Larger parties generally leave more dollars per bill, with exceptions.
- Two-person tables contribute $402.84 of $731.58 in tips (55.06%) across 156 of 244 bills.

## Limits
This is descriptive analysis of one small restaurant sample. It does not establish causation, statistical significance, or a basis for staffing or table-allocation changes. Identical rows and the highest tip rate are flagged and retained. See the notebook for full definitions and limitations.

## Run
1. Extract this ZIP and keep `analysis.ipynb` beside `tips.csv`.
2. Open the notebook in Jupyter, or upload both files to the same Google Colab session.
3. Use a Python environment with pandas, matplotlib, and seaborn installed. Run cells from top to bottom.
4. If `tips.csv` is absent, the notebook falls back to `sns.load_dataset('tips')`, which may require internet access.

The notebook includes saved outputs and charts for viewing without execution.

## Data source
The bundled `tips.csv` is the seaborn tips dataset, retrieved through `sns.load_dataset('tips')` without removing or changing source rows.
Source repository: https://github.com/mwaskom/seaborn-data/blob/master/tips.csv

## Files
- `analysis.ipynb`: executable notebook with results and charts.
- `tips.csv`: source-data snapshot.
- `README.md`: overview and run instructions.
